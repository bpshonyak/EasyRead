# EasyRead
A Chrome Extension that parses highlighted text and replaces it with a simplified version.
